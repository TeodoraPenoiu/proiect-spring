package jead.proiect.teodora.model;

import java.util.Collection;
import java.util.LinkedList;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "employees")
public class Employee {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id")
  private Long id;

  @Column(name = "name", nullable = false, length = 64)
  private String name;

  @Column(name = "number", nullable = false, unique = true)
  private String number;

  @OneToMany(mappedBy = "employee")
  private Collection<Shift> shifts = new LinkedList<Shift>();

  public Employee() {
  }

  public Employee(Long id) {
    this.id = id;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getNumber() {
	return number;
  }

  public void setNumber(String number) {
	this.number = number;
  }

  public Collection<Shift> getShifts() {
    return shifts;
  }

  public void setShifts(Collection<Shift> shifts) {
    this.shifts = shifts;
  }

}
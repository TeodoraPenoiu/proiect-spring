package jead.proiect.teodora.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jead.proiect.teodora.model.Cart;

@Repository("cartRepository")
public interface CartRepository extends JpaRepository<Cart, Long>, JpaSpecificationExecutor<Cart> {
	@Query("select p from Pizza p where p.name = :name")
	Cart findByName(@Param("name") String name);
}

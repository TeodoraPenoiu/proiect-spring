package jead.proiect.teodora.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jead.proiect.teodora.database.ShiftDb;
import jead.proiect.teodora.model.Employee;
import jead.proiect.teodora.model.Shift;
import jead.proiect.teodora.service.EmployeeService;
import jead.proiect.teodora.service.ShiftService;

@Controller
public class ShiftController {

  private final Logger logger = LoggerFactory.getLogger(ShiftController.class);
  
  @Autowired
  private ShiftService shiftService;

  @Autowired
  private EmployeeService employeeService;

  @RequestMapping(value = "/shifts", method = RequestMethod.GET)
  public String getShifts(Model model) {
    List<Shift> shifts = shiftService.findAllShifts();
    model.addAttribute("shifts", shifts);
    return "shifts";
  }

  @RequestMapping(value = "/shift/add", method = RequestMethod.GET)
  public String getAddShiftForm(Model model) {
    List<Employee> employees = employeeService.findAllEmployees();
    model.addAttribute("employees", employees);

    ShiftDb shift = new ShiftDb();
    model.addAttribute("shift", shift);
    return "add-shift";
  }

  @RequestMapping(value = "/shift/add", method = RequestMethod.POST)
  public String addShiftForm(@Valid @ModelAttribute("shift") ShiftDb shiftDb, BindingResult result, Model model, RedirectAttributes redirectAttributes) {
    if (result.hasErrors()) {
      logger.error("Add shift error: " + result.getAllErrors());
      List<Employee> employees = employeeService.findAllEmployees();
      model.addAttribute("employees", employees);
      return "add-shift";
    } else {
      Shift shift = new Shift();
      shift.setStatus(Shift.Status.NOT_STARTED);
      shift.setDueDate(shiftDb.getDueDate());
      shift.setEmployee(new Employee(shiftDb.getEmployeeId()));
      shiftService.add(shift);
      redirectAttributes.addFlashAttribute("message", "Successfully added..");
      return "redirect:/shifts";
    }
  }

  @RequestMapping(value = "/shift/update", method = RequestMethod.GET)
  public String getEditShiftForm(@RequestParam(value = "id", required = true) Long id, Model model,  RedirectAttributes redirectAttributes) {
    Shift shift = shiftService.findShift(id);
    if (shift != null) {
      logger.debug("Edit shift {}", shift);
      ShiftDb shiftDb = new ShiftDb();
      shiftDb.setId(shift.getId());
      shiftDb.setStatus(shift.getStatus());
      shiftDb.setDueDate(shift.getDueDate());
      shiftDb.setEmployeeId(shift.getEmployee().getId()); 
      
      model.addAttribute("shift", shiftDb);
      
      List<Employee> employees = employeeService.findAllEmployees();
      model.addAttribute("employees", employees);
      model.addAttribute("statuses", Shift.Status.values());
      
      return "update-shift";
    } else {
      logger.error("Edit error: Shift with id {} not found", id);
      redirectAttributes.addFlashAttribute("errorMessage", "Shift with specified id not found");
      return "redirect:/shifts";
    }
    
  }

  @RequestMapping(value = "/shift/update", method = RequestMethod.POST)
  public String updateShift(@Valid @ModelAttribute("shift") ShiftDb shiftDb, BindingResult result, Model model,  RedirectAttributes redirectAttributes) {
    if (result.hasErrors()) {
      logger.error("Update shift validation error: " + result.getAllErrors());
      
      List<Employee> employees = employeeService.findAllEmployees();
      model.addAttribute("employees", employees);
      model.addAttribute("statuses", Shift.Status.values());
      
      return "update-shift";      
    } else {
      Shift shift = new Shift();
      shift.setId(shiftDb.getId());
      shift.setStatus(shiftDb.getStatus());
      shift.setDueDate(shiftDb.getDueDate());
      shift.setEmployee(new Employee(shiftDb.getEmployeeId()));
      shiftService.update(shift); 
      
      return "redirect:/shifts";
    }
  }
  
  @RequestMapping(value = "/shift/delete", method = RequestMethod.GET)
  public String deleteShift(@Valid @ModelAttribute("id") Long id,  
      BindingResult result,  RedirectAttributes redirectAttributes) {
    try{
      shiftService.delete(id);
      redirectAttributes.addFlashAttribute("message", "Successfully deleted..");
    } catch (Exception e){
      redirectAttributes.addFlashAttribute("errorMessage", "Delete error: " + e.getMessage());
    }
    
     return "redirect:/shifts";
  }

}

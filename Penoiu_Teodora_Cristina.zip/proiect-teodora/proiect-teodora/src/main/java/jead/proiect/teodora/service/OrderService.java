package jead.proiect.teodora.service;

import jead.proiect.teodora.model.Order;

public interface OrderService {
	public Order add(Order order);
}

package jead.proiect.teodora.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jead.proiect.teodora.model.Employee;

@Repository("employeeRepository")
public interface EmployeeRepository extends JpaRepository<Employee, Long>, JpaSpecificationExecutor<Employee> {
  @Query("select p from Employee p where p.name = :name")
  Employee findByName(@Param("name") String name);

  Employee findByNumber(@Param("number") String number);

  @Query("SELECT p FROM Employee p WHERE p.name LIKE :searchTerm OR p.number LIKE :searchTerm")
  public List<Employee> search(@Param("searchTerm") String searchTerm);

}
package jead.proiect.teodora.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import jead.proiect.teodora.exception.DuplicateRecordException;
import jead.proiect.teodora.model.Order;
import jead.proiect.teodora.service.CartService;
import jead.proiect.teodora.service.OrderService;

@Controller
public class OrderController {
	private final Logger logger = LoggerFactory.getLogger(PizzaController.class);
	
	@Autowired
	private CartService cartService;
	
	@Autowired
	private OrderService orderService;
	
	@RequestMapping(value = "/validate-order", method = RequestMethod.GET)
	public String buy(Model model, @RequestParam(value = "price", required = true) String price) {
		model.addAttribute("price", price);
		return "validate-order";
	}
	
	@RequestMapping(value = "/validate-order", method = RequestMethod.POST)
	public String buy(@Valid @ModelAttribute("price") String price, BindingResult result) {
		if(!price.equals("0")) {
			try {
		    	Order orderToAdd = new Order();
		    	orderToAdd.setPrice(price);
		        
		        if(orderToAdd != null) {
		        	orderService.add(orderToAdd);
		        	cartService.delete();
		        }
		    } catch(DuplicateRecordException e) {
		        logger.error("Validate order error.");
		        return "validate-order";
		    }
		    return "redirect:/menu";
		} else {
			logger.error("The order has no items in it.");
		    return "shopping-cart";
		}
	}
	
}

package jead.proiect.teodora.database;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class CartDb {
	private Long id;

	@NotBlank(message = "The pizza name field can not be empty")
	@Size(max = 64, message = "The pizza name field can exceed 64 characters")
	private String name;

	@Digits(message = "The price is invalid", fraction = 2, integer = 10)
	private String price;
	
	public CartDb() {
		
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}
}

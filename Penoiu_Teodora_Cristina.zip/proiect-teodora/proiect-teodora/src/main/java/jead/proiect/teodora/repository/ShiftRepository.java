package jead.proiect.teodora.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import jead.proiect.teodora.model.Shift;

@Repository("shiftRepository")
public interface ShiftRepository extends JpaRepository<Shift, Long>, JpaSpecificationExecutor<Shift> {

  public List<Shift> findByEmployeeId(Long employeeId);

}
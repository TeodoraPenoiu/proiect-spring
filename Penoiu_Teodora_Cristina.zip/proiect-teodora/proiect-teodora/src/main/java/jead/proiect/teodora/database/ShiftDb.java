package jead.proiect.teodora.database;

import java.util.Date;

import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import jead.proiect.teodora.model.Shift;

public class ShiftDb {
  private Long id;

  @DateTimeFormat(pattern = "dd-MM-yyyy")
  private Date dueDate;

  private Shift.Status status;

  @NotNull
  private Long employeeId;

  public ShiftDb() {

  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Date getDueDate() {
    return dueDate;
  }

  public void setDueDate(Date dueDate) {
    this.dueDate = dueDate;
  }

  public Shift.Status getStatus() {
    return status;
  }

  public void setStatus(Shift.Status status) {
    this.status = status;
  }

  public Long getEmployeeId() {
    return employeeId;
  }

  public void setEmployeeId(Long employeeId) {
    this.employeeId = employeeId;
  }
}

package jead.proiect.teodora.database;

import javax.validation.constraints.Digits;

public class OrderDb {
	private Long id;
	
	@Digits(message = "The price is invalid", fraction = 2, integer = 10)
	private String price;
	
	public OrderDb() {
		
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}
}

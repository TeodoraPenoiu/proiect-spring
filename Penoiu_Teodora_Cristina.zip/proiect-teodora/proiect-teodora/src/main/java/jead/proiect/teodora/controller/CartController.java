package jead.proiect.teodora.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jead.proiect.teodora.exception.DuplicateRecordException;
import jead.proiect.teodora.model.Cart;
import jead.proiect.teodora.model.Pizza;
import jead.proiect.teodora.service.CartService;
import jead.proiect.teodora.service.PizzaService;

@Controller
public class CartController {
	private final Logger logger = LoggerFactory.getLogger(PizzaController.class);
	
	@Autowired
	private PizzaService pizzaService;
	
	@Autowired
	private CartService cartService;
	
	@RequestMapping(value = "/shopping-cart", method = RequestMethod.GET)
	public String showShoppingCart(Model model) {
		List<Cart> cart = cartService.findAllPizzas();
		model.addAttribute("cart", cart);
		return "shopping-cart";
	}
	
	@RequestMapping(value = "/add-to-cart", method = RequestMethod.GET)
	public String buy(Model model, @RequestParam(value = "id", required = true) Long id, RedirectAttributes redirectAttributes) {
		Pizza pizza = pizzaService.findPizza(id);
		if(pizza != null) {
			
			model.addAttribute("cart", pizza);
			return "add-to-cart";
		} else {
			redirectAttributes.addFlashAttribute("errorMessage", "The pizza was not found");
		    return "redirect:/menu";
		}
	}
	
	@RequestMapping(value = "/add-to-cart", method = RequestMethod.POST)
	public String buy(@Valid @ModelAttribute("cart") Pizza pizza, BindingResult result) {
		try {
	    	Cart pizzaToAdd = new Cart();
	    	pizzaToAdd.setName(pizza.getName());
	    	pizzaToAdd.setPrice(pizza.getPrice());
	        
	        if(pizzaToAdd != null) {
	        	cartService.add(pizzaToAdd);
	        }
	    } catch(DuplicateRecordException e) {
	        logger.error("There was an error when adding the pizza to the shopping cart.");
	        return "add-to-cart";
	    }
	    return "redirect:/menu";
	}
	
	@RequestMapping(value = "/cart/delete", method = RequestMethod.GET)
	public String deletePizza(@Valid @ModelAttribute("id") Long id, BindingResult result,  RedirectAttributes redirectAttributes) {
	    try{
	      cartService.delete(id);
	      redirectAttributes.addFlashAttribute("message", "Successfully deleted.");
	    } catch (DataIntegrityViolationException e) {
	      String errorMessage = "Can not delete pizza";
	      logger.error(errorMessage);
	      redirectAttributes.addFlashAttribute("errorMessage", errorMessage);
	    } catch (Exception e){
	      redirectAttributes.addFlashAttribute("errorMessage", "Delete error: " + e.getMessage());      
	    }
	    
	     return "redirect:/shopping-cart";
	}
}

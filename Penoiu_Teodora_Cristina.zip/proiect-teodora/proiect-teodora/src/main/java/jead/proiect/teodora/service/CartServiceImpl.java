package jead.proiect.teodora.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jead.proiect.teodora.exception.RecordNotFoundException;
import jead.proiect.teodora.model.Cart;
import jead.proiect.teodora.repository.CartRepository;

@Service("cartService")
public class CartServiceImpl implements CartService {
	private static final Logger logger = LoggerFactory.getLogger(CartServiceImpl.class);
	
	@Autowired
	private CartRepository cartRepository;
	
	@Override
	public List<Cart> findAllPizzas() {
		return cartRepository.findAll();
	}
	
	@Override
	@Transactional
	public Cart add(Cart pizza) {
		cartRepository.save(pizza);
	    return pizza;
	}
	
	@Override
	@Transactional
	public void delete(Long pizzaId) {
	    Cart pizza = cartRepository.findById(pizzaId).orElse(null);
	    logger.debug("Delete the pizza with id: " + pizzaId + " from shopping cart");
	    if (pizza != null) {
	      cartRepository.delete(pizza);
	    } else {
	      String errorMessage = "Pizza with id " + pizzaId + " was not found";
	      logger.error(errorMessage);
	      throw new RecordNotFoundException(errorMessage);
	    }
	}

	@Override
	public void delete() {
		cartRepository.deleteAll();
	}
}

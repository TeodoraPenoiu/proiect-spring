package jead.proiect.teodora.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jead.proiect.teodora.exception.DuplicateRecordException;
import jead.proiect.teodora.exception.RecordNotFoundException;
import jead.proiect.teodora.model.Pizza;
import jead.proiect.teodora.repository.PizzaRepository;

@Service("pizzaService")
public class PizzaServiceImpl implements PizzaService {

  private static final Logger logger = LoggerFactory.getLogger(PizzaServiceImpl.class);

  @Autowired
  private PizzaRepository pizzaRepository;

  @Override
  public Pizza findPizza(Long pizzaId) {
    return pizzaRepository.findById(pizzaId).orElse(null);
  }

  @Override
  public Pizza findPizza(String name) {
    return pizzaRepository.findByName(name);
  }

  @Override
  public List<Pizza> findAllPizzas() {
    return pizzaRepository.findAll();
  }

  @Override
  @Transactional
  public Pizza add(Pizza pizza) {
    Pizza existingPizza = pizzaRepository.findByName(pizza.getName());
    if (existingPizza != null) {
      String errorMessage = "Already exists a pizza with the same name: " + pizza.getName();
      logger.error(errorMessage);
      throw new DuplicateRecordException(errorMessage);
    }
    pizzaRepository.save(pizza);
    return pizza;
  }

  @Override
  @Transactional
  public Pizza update(Pizza pizza) {
    Pizza existingPizza = pizzaRepository.findById(pizza.getId()).orElse(null);
    if (existingPizza == null) {
      String errorMessage = "Pizza with id " + pizza.getId() + " was not found";
      logger.error(errorMessage);
      throw new RecordNotFoundException(errorMessage);
    }

    if (!existingPizza.getName().equals(pizza.getName())) {
      if (pizzaRepository.findByName(pizza.getName()) != null) {
        String errorMessage = "The new name is already being used by another pizza: " + pizza.getName();
        logger.error(errorMessage);
        throw new DuplicateRecordException(errorMessage);
      }
    }
    
    if (pizza.getDescription() == null) {
        pizza.setDescription(existingPizza.getDescription());
    }
    
    if (pizza.getImage() == null) {
      pizza.setImage(existingPizza.getImage());
    }
    
    if (pizza.getPrice() == null) {
      pizza.setPrice(existingPizza.getPrice());
    }

    return pizzaRepository.save(pizza);
  }

  @Override
  @Transactional
  public void delete(Long pizzaId) {
    Pizza pizza = pizzaRepository.findById(pizzaId).orElse(null);
    logger.debug("Delete the pizza with id: " + pizzaId);
    if (pizza != null) {
      pizzaRepository.delete(pizza);
    } else {
      String errorMessage = "Pizza with id " + pizzaId + " was not found";
      logger.error(errorMessage);
      throw new RecordNotFoundException(errorMessage);
    }
  }
}

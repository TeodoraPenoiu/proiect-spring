package jead.proiect.teodora.service;

import java.util.List;

import jead.proiect.teodora.model.Pizza;

public interface PizzaService {
  public Pizza findPizza(Long pizzaId);

  public Pizza findPizza(String name);

  public List<Pizza> findAllPizzas();

  public Pizza add(Pizza pizza);

  public Pizza update(Pizza pizza);

  public void delete(Long pizzaId);
}

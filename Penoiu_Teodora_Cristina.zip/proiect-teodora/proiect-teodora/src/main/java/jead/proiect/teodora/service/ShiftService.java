package jead.proiect.teodora.service;

import java.util.List;

import jead.proiect.teodora.model.Shift;

public interface ShiftService {

  public Shift findShift(Long shiftId);

  public List<Shift> findAllShifts();

  public List<Shift> findEmployeeShifts(Long employeeId);

  public Shift add(Shift shift);

  public Shift update(Shift shift);

  public void delete(Long shiftId);
}

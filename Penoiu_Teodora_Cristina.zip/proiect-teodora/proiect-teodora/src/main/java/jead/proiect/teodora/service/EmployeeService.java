package jead.proiect.teodora.service;

import java.util.List;

import jead.proiect.teodora.model.Employee;

public interface EmployeeService {
  public Employee findEmployee(Long employeeId);

  public Employee findEmployee(String name);

  public List<Employee> findAllEmployees();

  public Employee add(Employee employee);

  public Employee update(Employee employee);

  public void delete(Long employeeId);
}

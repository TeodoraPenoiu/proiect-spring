package jead.proiect.teodora.database;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class EmployeeDb {

  private Long id;

  @NotBlank(message = "The employee name can not be empty")
  @Size(max = 64, message = "The employee name can not exceed 64 characters")
  private String name;

  @NotBlank(message = "The employee phone number can not be empty")
  @Digits(message = "The employee phone number is invalid", fraction = 0, integer = 10)
  private String number;

  public EmployeeDb() {
  }

  public EmployeeDb(Long id) {
    this.id = id;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getNumber() {
	return number;
  }

  public void setNumber(String number) {
	this.number = number;
  }

}
package jead.proiect.teodora.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jead.proiect.teodora.model.Order;
import jead.proiect.teodora.repository.OrderRepository;

@Service("orderService")
public class OrderServiceImpl implements OrderService {
	
	@Autowired
	private OrderRepository orderRepository;

	@Override
	public Order add(Order order) {
		orderRepository.save(order);
		return order;
	}

}

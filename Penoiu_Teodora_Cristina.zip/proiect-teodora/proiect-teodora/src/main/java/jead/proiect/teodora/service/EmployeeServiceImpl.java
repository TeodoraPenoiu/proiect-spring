package jead.proiect.teodora.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jead.proiect.teodora.exception.DuplicateRecordException;
import jead.proiect.teodora.exception.RecordNotFoundException;
import jead.proiect.teodora.model.Employee;
import jead.proiect.teodora.repository.EmployeeRepository;

@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService {

  private static final Logger logger = LoggerFactory.getLogger(EmployeeServiceImpl.class);

  @Autowired
  private EmployeeRepository employeeRepository;

  @Override
  public Employee findEmployee(Long employeeId) {
    return employeeRepository.findById(employeeId).orElse(null);
  }

  @Override
  public Employee findEmployee(String name) {
    return employeeRepository.findByName(name);
  }

  @Override
  public List<Employee> findAllEmployees() {
    return employeeRepository.findAll();
  }

  @Override
  @Transactional
  public Employee add(Employee employee) {
	Employee existingEmployee = employeeRepository.findByNumber(employee.getNumber());
    if (existingEmployee != null) {
      String errorMessage = "The already is an employee with the same phone number: " + employee.getNumber();
      logger.error(errorMessage);
      throw new DuplicateRecordException(errorMessage);
    }
    employeeRepository.save(employee);
    return employee;
  }

  @Override
  @Transactional
  public Employee update(Employee employee) {
	Employee existingEmployee = employeeRepository.findById(employee.getId()).orElse(null);
    if (existingEmployee == null) {
      String errorMessage = "The employee with id " + employee.getId() + " was not found";
      logger.error(errorMessage);
      throw new RecordNotFoundException(errorMessage);
    }

    if (!existingEmployee.getNumber().equals(employee.getNumber())) {
      if (employeeRepository.findByNumber(employee.getNumber()) != null) {
        String errorMessage = "The new phone number is already being used by another employee: " + employee.getNumber();
        logger.error(errorMessage);
        throw new DuplicateRecordException(errorMessage);
      }
    }

    return employeeRepository.save(employee);
  }

  @Override
  @Transactional
  public void delete(Long employeeId) {
	Employee employee = employeeRepository.findById(employeeId).orElse(null);
    logger.debug("Delete employee with id: " + employeeId);
    if (employee != null) {
    	employeeRepository.delete(employee);
    } else {
      String errorMessage = "The employee with id " + employeeId + " was not found";
      logger.error(errorMessage);
      throw new RecordNotFoundException(errorMessage);
    }
  }

}

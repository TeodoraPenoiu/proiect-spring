package jead.proiect.teodora.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jead.proiect.teodora.exception.RecordNotFoundException;
import jead.proiect.teodora.model.Shift;
import jead.proiect.teodora.repository.ShiftRepository;

@Service("shiftService")
public class ShiftServiceImpl implements ShiftService {

  private static final Logger logger = LoggerFactory.getLogger(ShiftServiceImpl.class);

  @Autowired
  private ShiftRepository shiftRepository;

  @Override
  public Shift findShift(Long shiftId) {
    Shift shift = shiftRepository.findById(shiftId).orElse(null);
    return shift;
  }

  @Override
  @Transactional(readOnly = true)
  public List<Shift> findAllShifts() {
    return shiftRepository.findAll();
  }

  @Override
  @Transactional(readOnly = true)
  public List<Shift> findEmployeeShifts(Long employeeId) {
    return shiftRepository.findByEmployeeId(employeeId);
  }

  @Override
  @Transactional
  public Shift add(Shift shift) {
    shiftRepository.save(shift);
    return shift;
  }

  @Override
  @Transactional
  public Shift update(Shift shift) {
    Shift existingShift = shiftRepository.findById(shift.getId()).orElse(null);
    if (existingShift == null) {
      String errorMessage = "The shift with id " + shift.getId() + " was not found";
      logger.error(errorMessage);
      throw new RecordNotFoundException(errorMessage);
    }
    return shiftRepository.save(shift);
  }

  @Override
  @Transactional
  public void delete(Long shiftId) {
    Shift shift = shiftRepository.findById(shiftId).orElse(null);
    logger.debug("Delete shift with id: " + shiftId);
    if (shift != null) {
      shiftRepository.deleteById(shiftId);
    } else {
      String errorMessage = "The shift with id " + shiftId + " was not found";
      logger.error(errorMessage);
      throw new RecordNotFoundException(errorMessage);
    }
  }

}

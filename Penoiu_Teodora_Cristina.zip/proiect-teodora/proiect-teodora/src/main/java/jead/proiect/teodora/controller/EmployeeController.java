package jead.proiect.teodora.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ValidationUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jead.proiect.teodora.database.EmployeeDb;
import jead.proiect.teodora.exception.DuplicateRecordException;
import jead.proiect.teodora.model.Employee;
import jead.proiect.teodora.model.Shift;
import jead.proiect.teodora.service.EmployeeService;
import jead.proiect.teodora.service.ShiftService;

@Controller
public class EmployeeController {

  private final Logger logger = LoggerFactory.getLogger(EmployeeController.class);
  @Autowired
  private EmployeeService employeeService;
  
  @Autowired
  private ShiftService shiftService;
  
  @RequestMapping(value = "/employees", method = RequestMethod.GET)
  public String getEmployees(Model model) {
    List<Employee> employees = employeeService.findAllEmployees();
    model.addAttribute("employees", employees);
    return "employees";
  }  
  
  @RequestMapping(value = "/employee/{employeeId}/shifts", method = RequestMethod.GET)
  public String getEmployeeShifts(@PathVariable("employeeId") Long employeeId, Model model) {
    List<Shift> shifts = shiftService.findEmployeeShifts(employeeId);
    model.addAttribute("shifts", shifts);
    return "shifts";
  }
  
  @RequestMapping(value = "/employee/add", method = RequestMethod.GET)
  public String getAddEmployeeForm(Model model) {
	EmployeeDb employee = new EmployeeDb();
    model.addAttribute("employee", employee);
    return "add-employee";
  }
  
  @RequestMapping(value = "/employee/add", method = RequestMethod.POST)
  public String addEmployeeForm(@Valid @ModelAttribute("employee") EmployeeDb employeeDb, BindingResult result, RedirectAttributes redirectAttributes) {
    ValidationUtils.rejectIfEmptyOrWhitespace(result, "number", "notEmpty.number", "number can not be empty");
    if (result.hasErrors()){
      logger.error("Add employee error: {}",  result.getAllErrors());
      return "add-employee";
    } else {
      try {
    	Employee employeeToAdd = new Employee();
    	employeeToAdd.setName(employeeDb.getName());
    	employeeToAdd.setNumber(employeeDb.getNumber());
        
        employeeService.add(employeeToAdd);
      } catch(DuplicateRecordException e) {
        result.rejectValue("number", "duplicate", "number already used");
        logger.error("Add employee error: " +  result.getAllErrors());
        return "add-employee";
      }
      redirectAttributes.addFlashAttribute("message", "Successfully added..");
      return "redirect:/employees";
    }
  }
  
  @RequestMapping(value = "/employee/update", method = RequestMethod.GET)
  public String getEditEmployeeForm(Model model, @RequestParam(value = "id", required = true) Long id, RedirectAttributes redirectAttributes) {
	Employee existingEmployee = employeeService.findEmployee(id);
    if(existingEmployee != null){
      EmployeeDb employeeDb = new EmployeeDb();
      employeeDb.setId(existingEmployee.getId());
      employeeDb.setName(existingEmployee.getName());
      employeeDb.setNumber(existingEmployee.getNumber());
      
      model.addAttribute("employee", employeeDb);
      return "update-employee";
    } else {
      redirectAttributes.addFlashAttribute("errorMessage", "The employee was not found");
      return "redirect:/employees";
    }
    
  }
  
  @RequestMapping(value = "/employee/update", method = RequestMethod.POST)
  public String updateEmployee(@Valid @ModelAttribute("employee") EmployeeDb employeeDb, BindingResult result) {
    if (result.hasErrors()) {
      logger.error("Update employee error: " + result.getAllErrors());
      return "update-employee";
    } else {
      try {
    	Employee employeeToUpdate = new Employee();
    	employeeToUpdate.setId(employeeDb.getId());
    	employeeToUpdate.setName(employeeDb.getName());
    	employeeToUpdate.setNumber(employeeDb.getNumber());

        employeeService.update(employeeToUpdate);
      } catch (DuplicateRecordException e) {
        result.rejectValue("number", "duplicate", "The new phone number is already being used by another employee");
        logger.error("Update employee error: " + result.getAllErrors());
        return "update-employee";
      }
      return "redirect:/employees";
    }
  }
  
  @RequestMapping(value = "/employee/delete", method = RequestMethod.GET)
  public String deleteEmployee(@Valid @ModelAttribute("id") Long id,  
      BindingResult result,  RedirectAttributes redirectAttributes) {
    try{
      employeeService.delete(id);
      redirectAttributes.addFlashAttribute("message", "Successfully deleted.");
    } catch (DataIntegrityViolationException e) {
      String errorMessage = "Can not delete employee because is assigned";
      logger.error(errorMessage);
      redirectAttributes.addFlashAttribute("errorMessage", errorMessage);
    } catch (Exception e){
      redirectAttributes.addFlashAttribute("errorMessage", "Delete error: " + e.getMessage());      
    }
    
     return "redirect:/employees";
  }
  
    
}


package jead.proiect.teodora.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "shifts")
public class Shift {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id")
  private Long id;

  @Temporal(TemporalType.DATE)
  @DateTimeFormat(pattern = "dd-MM-yyyy")
  @Column(name = "dueDate")
  private Date dueDate;

  @Enumerated(EnumType.STRING)
  @Column(name = "status")
  private Status status = Status.NOT_STARTED;

  @ManyToOne
  @JoinColumn(name = "employeeId", nullable = false)
  private Employee employee;

  public Shift() {

  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Date getDueDate() {
    return dueDate;
  }

  public void setDueDate(Date dueDate) {
    this.dueDate = dueDate;
  }

  public Status getStatus() {
    return status;
  }

  public void setStatus(Status status) {
    this.status = status;
  }

  public Employee getEmployee() {
    return employee;
  }

  public void setEmployee(Employee employee) {
    this.employee = employee;
  }

  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("Shift[");
    sb.append("id=" + id);
    sb.append(", status =" + status);
    if (getEmployee() != null) {
      sb.append(", employeeId =" + getEmployee().getId());
    }
    sb.append("]");
    return sb.toString();

  }

  public static enum Status {
    NOT_STARTED("not started"), IN_PROGRESS("in progress"), DONE("done");

    private final String displayName;

    Status(String displayName) {
      this.displayName = displayName;
    }

    public String getDisplayName() {
      return displayName;
    }
  }

}

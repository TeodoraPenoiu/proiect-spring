package jead.proiect.teodora.service;

import java.util.List;

import jead.proiect.teodora.model.Cart;

public interface CartService {
	public List<Cart> findAllPizzas();
	
	public Cart add(Cart pizza);
	
	public void delete(Long pizzaId);

	public void delete();
}

package jead.proiect.teodora.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ValidationUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jead.proiect.teodora.database.PizzaDb;
import jead.proiect.teodora.exception.DuplicateRecordException;
import jead.proiect.teodora.model.Pizza;
import jead.proiect.teodora.service.PizzaService;

@Controller
public class PizzaController {

  private final Logger logger = LoggerFactory.getLogger(PizzaController.class);
  @Autowired
  private PizzaService pizzaService;
  
  @RequestMapping("/home")
  public String showHomepage() {
	return "home";
  }
  
  @RequestMapping("/contact")
  public String showContact() {
	return "contact";
  }
  
  @RequestMapping(value = "/menu", method = RequestMethod.GET)
  public String getPizzas(Model model) {
    List<Pizza> pizzas = pizzaService.findAllPizzas();
    model.addAttribute("menu", pizzas);
    return "menu";
  }
  
  @RequestMapping(value = "/change", method = RequestMethod.GET)
  public String showMenuAdministratorPage(Model model) {
	List<Pizza> pizzas = pizzaService.findAllPizzas();
	model.addAttribute("pizzas", pizzas);
	return "change";
  }
    
  @RequestMapping(value = "/pizza/add", method = RequestMethod.GET)
  public String getAddPizzaForm(Model model) {
    PizzaDb pizzaDb = new PizzaDb();
    model.addAttribute("pizza", pizzaDb);
    return "add-pizza";
  }
  
  @RequestMapping(value = "/pizza/add", method = RequestMethod.POST)
  public String addPizzaForm(@Valid @ModelAttribute("pizza") PizzaDb pizzaDb, BindingResult result, RedirectAttributes redirectAttributes) {
    ValidationUtils.rejectIfEmptyOrWhitespace(result, "image", "notEmpty.image", "image can not be empty");
    if (result.hasErrors()){
      logger.error("Add pizza error: {}",  result.getAllErrors());
      return "add-pizza";
    } else {
      try {
        Pizza pizzaToAdd = new Pizza();
        pizzaToAdd.setName(pizzaDb.getName());
        pizzaToAdd.setDescription(pizzaDb.getDescription());
        pizzaToAdd.setPrice(pizzaDb.getPrice());
        pizzaToAdd.setImage(pizzaDb.getImage());
        pizzaService.add(pizzaToAdd);
      } catch(DuplicateRecordException e) {
        result.rejectValue("image", "duplicate", "image already used");
        logger.error("Add pizza error: " +  result.getAllErrors());
        return "add-pizza";
      }
      redirectAttributes.addFlashAttribute("message", "Successfully added..");
      return "redirect:/menu";
    }
  }
  
  @RequestMapping(value = "/pizza/update", method = RequestMethod.GET)
  public String getEditPizzaForm(Model model, @RequestParam(value = "id", required = true) Long id,  RedirectAttributes redirectAttributes) {
    Pizza existingPizza = pizzaService.findPizza(id);
    if(existingPizza != null){
      PizzaDb pizzaDb = new PizzaDb();
      pizzaDb.setId(existingPizza.getId());
      pizzaDb.setName(existingPizza.getName());
      pizzaDb.setDescription(existingPizza.getDescription());
      pizzaDb.setImage(existingPizza.getImage());// Do not sent password.
      pizzaDb.setPrice(existingPizza.getPrice());
      model.addAttribute("pizza", pizzaDb);
      return "update-pizza";
    } else {
      redirectAttributes.addFlashAttribute("errorMessage", "Pizza not found");
      return "redirect:/change";
    }
    
  }
  
  @RequestMapping(value = "/pizza/update", method = RequestMethod.POST)
  public String updatePizza(@Valid @ModelAttribute("pizza") PizzaDb pizzaDb, BindingResult result) {
    if (result.hasErrors()) {
      logger.error("Update pizza error: " + result.getAllErrors());
      return "update-pizza";
    } else {
      try {
        Pizza pizzaToUpdate = new Pizza();
        pizzaToUpdate.setId(pizzaDb.getId());
        pizzaToUpdate.setName(pizzaDb.getName());
        pizzaToUpdate.setDescription(pizzaDb.getDescription());
        pizzaToUpdate.setImage(pizzaDb.getImage());// Do not sent password.
        pizzaToUpdate.setPrice(pizzaDb.getPrice());

        pizzaService.update(pizzaToUpdate);
      } catch (DuplicateRecordException e) {
        result.rejectValue("name", "duplicate", "New name already used by another pizza");
        logger.error("Update pizza error: " + result.getAllErrors());
        return "update-pizza";
      }
      return "redirect:/change";
    }
  }
  
  @RequestMapping(value = "/pizza/delete", method = RequestMethod.GET)
  public String deletePizza(@Valid @ModelAttribute("id") Long id,  
      BindingResult result,  RedirectAttributes redirectAttributes) {
    try{
      pizzaService.delete(id);
      redirectAttributes.addFlashAttribute("message", "Successfully deleted.");
    } catch (DataIntegrityViolationException e) {
      String errorMessage = "Can not delete pizza because is assigned";
      logger.error(errorMessage);
      redirectAttributes.addFlashAttribute("errorMessage", errorMessage);
    } catch (Exception e){
      redirectAttributes.addFlashAttribute("errorMessage", "Delete error: " + e.getMessage());      
    }
    
     return "redirect:/change";
  }
}
